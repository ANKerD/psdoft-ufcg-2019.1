package br.edu.ufcg.ccc.anderson.dantas.lab1.rest;

public class ServerTime {
    private String serverTime;

    public ServerTime(String serverTime) {
        this.serverTime = serverTime;
    }

    public String getServerTime() {
        return serverTime;
    }
}
